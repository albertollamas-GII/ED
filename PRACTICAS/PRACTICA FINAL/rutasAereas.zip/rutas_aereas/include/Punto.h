#include <iostream>
#include <string>

using namespace std;

class Punto{
    private:
        double latitud, longitud;
    
    public:
    Punto(){
        latitud = longitud = 0;
    }
    Punto(double l, double L) : latitud(l), longitud(L) {} //, const string &d (Tiene puesto este parametro pero no se para que sirve)
    double getLatitud() const;
    double getLongitud() const;
    void setLatitud(double l);
    void setLongitud(double l);
    bool operator < (const Punto& p) const;
    bool operator==(const Punto &p) const;
    friend istream& operator >> (istream &is, Punto &p);
    friend ostream& operator << (ostream &os, const Punto &p);
}