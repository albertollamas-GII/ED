#include "Punto.h"
#include <iostream>
#include <cassert>

double Punto::getLatitud() const{
    assert(latitud <= 90 || latitud >= -90);
    return latitud;
}
double Punto::getLongitud() const{
    assert(longitud <= 180 || longitud >= -180);
    return longitud;
}
void Punto::setLatitud(double l){
    assert(l <= 90 || l >= -90);
    this->latitud = l;
}
void Punto::setLongitud(double l){
    assert(l <= 180 || l >= -180);
    this->longitud = l;
}
bool Punto::operator<(const Punto &p) const{
    if (latitud < p.latitud && longitud == p.longitud)
        return true;
    else if (latitud == p.latitud && longitud < p.longitud)
        return true;
    else
        return false;
}
bool Punto::operator==(const Punto &p) const{
    if (latitud == p.latitud && longitud == p.longitud)
        return true;
    else
        return false;
}
//No seguro de si estan >> y << bien
istream &operator>>(istream &is, Punto &p){
    char parentesis[2], coma[1];
    double lat, long;
    is >> parentesis[0] >> p.latitud >> coma[0] >> p.longitud >> parentesis[1];
    is.ignore();
    Punto(lat, long);
    return is;
}

ostream &operator<<(ostream &os, const Punto &p){
        os << "(" << p.latitud << "," << p.longitud << ")";
        return os;
}
