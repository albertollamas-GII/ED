#include "Pais.h"

Punto Pais::GetPunto() const{
    return Punto;
}
string Pais::GetPais() const{
    return pais;
}
string Pais::GetBandera() const{
    return bandera;
}
bool Pais::operator<(const Pais &P) const{
    for (int i = 0; i < P.GetPais().size(); i++)
}
bool Pais::operator==(const Pais &P) const;
bool Pais::operator==(const Punto &P) const;